/* ColdGuard - ESP32
   Libraries: PubSubClient, ArduinoJson, Adafruit BMP280 Library
   Sensor assumption: BMP280 (temperature/pressure); humidity is null as in PDF.
   Replace TEAM, WIFI, BROKER and LED_PIN before upload.
*/
#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <Adafruit_BMP280.h>

#define TEAM "TXX"                 // เปลี่ยนเป็นเลขทีม เช่น T01
#define ROOM "room01"
#define LED_PIN 2
#define WIFI_SSID "YOUR_WIFI"
#define WIFI_PASS "YOUR_PASSWORD"
#define BROKER "172.16.20.10"      // IP เครื่อง MQTT Broker
#define MQTT_PORT 1883

WiFiClient net;
PubSubClient mqtt(net);
Adafruit_BMP280 bmp;
String base = "cg/" TEAM "/" ROOM;
String topicTelemetry, topicCmd, topicAck;

struct Reading { float temp, press, alt; uint32_t seq, measuredAt; };
Reading queueData[60];
int qHead=0, qTail=0, qCount=0;
uint32_t seqNo=0, lastSample=0, lastBlink=0;
bool alarmOn=false, ledState=false;

void sendAck() {
  StaticJsonDocument<96> d;
  d["alarm"] = alarmOn ? "on" : "off";
  d["uptime"] = millis()/1000;
  char out[96]; serializeJson(d,out);
  mqtt.publish(topicAck.c_str(),out);
}

void callback(char* topic, byte* payload, unsigned int len) {
  StaticJsonDocument<96> d;
  if (deserializeJson(d,payload,len)) return;
  const char* a=d["alarm"] | "off";
  alarmOn = (String(a)=="on");
  if (!alarmOn) { digitalWrite(LED_PIN,LOW); ledState=false; }
  sendAck();
}

bool connectMQTT() {
  while (!mqtt.connected()) {
    String id="cg-" ROOM "-" + String((uint32_t)ESP.getEfuseMac(),HEX);
    if (mqtt.connect(id.c_str())) {
      mqtt.subscribe(topicCmd.c_str());
      return true;
    }
    delay(1000);
  }
  return true;
}

bool publishReading(const Reading &r) {
  StaticJsonDocument<192> d;
  d["device"]=ROOM; d["temp"]=r.temp; d["press"]=r.press;
  d["alt"]=r.alt; d["hum"]=nullptr; d["seq"]=r.seq;
  d["age"]=(millis()-r.measuredAt)/1000;
  char out[192]; serializeJson(d,out);
  return mqtt.publish(topicTelemetry.c_str(),out);
}

void queueReading(const Reading &r) {
  if (qCount==60) { qTail=(qTail+1)%60; qCount--; } // เก็บล่าสุดได้ 60 ค่า
  queueData[qHead]=r; qHead=(qHead+1)%60; qCount++;
}

void flushQueue() {
  while (mqtt.connected() && qCount>0) {
    if (!publishReading(queueData[qTail])) break;
    qTail=(qTail+1)%60; qCount--;
    mqtt.loop();
  }
}

void setup() {
  pinMode(LED_PIN,OUTPUT); digitalWrite(LED_PIN,LOW);
  Serial.begin(115200);
  topicTelemetry=base+"/telemetry"; topicCmd=base+"/cmd"; topicAck=base+"/ack";
  if (!bmp.begin(0x76) && !bmp.begin(0x77)) Serial.println("BMP280 not found");
  WiFi.begin(WIFI_SSID,WIFI_PASS);
  while (WiFi.status()!=WL_CONNECTED) delay(500);
  mqtt.setServer(BROKER,MQTT_PORT); mqtt.setCallback(callback);
}

void loop() {
  if (WiFi.status()==WL_CONNECTED && !mqtt.connected()) connectMQTT();
  if (mqtt.connected()) { mqtt.loop(); flushQueue(); }

  if (millis()-lastSample>=5000) {
    lastSample=millis();
    Reading r={bmp.readTemperature(), bmp.readPressure()/100.0F,
               bmp.readAltitude(1013.25F), ++seqNo, millis()};
    if (mqtt.connected() && qCount==0) { if (!publishReading(r)) queueReading(r); }
    else queueReading(r);
    Serial.printf("T=%.1f P=%.1f seq=%lu queued=%d\n",r.temp,r.press,(unsigned long)r.seq,qCount);
  }

  if (alarmOn && millis()-lastBlink>=500) {
    lastBlink=millis(); ledState=!ledState; digitalWrite(LED_PIN,ledState);
  }
}
