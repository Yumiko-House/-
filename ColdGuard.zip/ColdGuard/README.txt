ColdGuard starter project

1) ESP32
- เปิด esp32/ColdGuard.ino ใน Arduino IDE
- ติดตั้ง PubSubClient, ArduinoJson และ Adafruit BMP280 Library
- ใช้ BMP280 ต่อ I2C (SDA=GPIO21, SCL=GPIO22, address 0x76 หรือ 0x77)
- แก้ TEAM, WIFI_SSID, WIFI_PASS และ BROKER ก่อน Upload
- LED ใช้ GPIO2 (แก้ LED_PIN ตามบอร์ดจริง)

2) Frontend
- วางโฟลเดอร์ web ไว้ใน Web server
- ให้ server ส่งหน้า index.html สำหรับ path /dash/* (SPA fallback) และเปิด /login.html
- API ต้องอยู่ที่ origin เดียวกันและมี Authorization: Bearer token
- หน้าเว็บคาดหวังข้อมูล API เป็น array หรือ {items:[...]}; ปรับชื่อ field ใน app.js ให้ตรง Backend
- ต้องให้ Backend/Node-RED เป็นผู้ตัดสินเกณฑ์ 15-30°C ต่อเนื่อง 3 ค่า, สร้าง incident แบบไม่ซ้ำ และ publish cmd alarm on/off ตาม PDF

API ที่หน้านี้เรียก:
POST /api/auth/login
GET /api/rooms
GET /api/readings?room=...&hours=... หรือ days=...
GET /api/incidents?days=7

หมายเหตุสำคัญ:
PDF ไม่ได้ระบุรุ่นเซนเซอร์, IP Broker, เลขทีม และโครงสร้าง JSON response ของ Backend จึงกำหนด BMP280 และรูปแบบ API ตัวอย่างไว้ก่อน ต้องปรับให้ตรงอุปกรณ์และ Backend จริง
Firmware buffer เก็บ 60 ค่าใน RAM และเพิ่ม seq/age ตามข้อกำหนด หากไฟดับหรือ ESP32 รีเซ็ต ข้อมูลใน RAM จะหาย
