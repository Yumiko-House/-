const API='/api';
document.querySelector('#loginForm').onsubmit=async e=>{
 e.preventDefault(); const f=new FormData(e.target);
 try{const r=await fetch(API+'/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:f.get('username'),password:f.get('password')})});
 const d=await r.json(); if(!r.ok)throw Error(d.message||'เข้าสู่ระบบไม่สำเร็จ');
 localStorage.setItem('token',d.token); localStorage.setItem('role',d.user?.role||d.role||'user1'); location.href='/dash/live';
 }catch(err){document.querySelector('#message').textContent=err.message;}
};
